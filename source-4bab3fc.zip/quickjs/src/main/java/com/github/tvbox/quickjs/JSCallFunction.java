package com.github.tvbox.quickjs;

public interface JSCallFunction {

    Object call(Object... args);

}
